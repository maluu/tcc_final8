<?php
/**
 * Created by PhpStorm.
 * User: Guilherme Otto
 * Date: 24/11/2018
 * Time: 19:35
 */
require_once "Conexao.php";
class Parecer
{
    public $parecer;

    public function __construct($parecer)
    {
        $this->parecer = $parecer;


    }

    /**
     * @return mixed
     */
    public function getParecer()
    {
        return $this->parecer;
    }

    /**
     * @param mixed $parecer
     */
    public function setParecer($parecer)
    {
        $this->parecer = $parecer;
    }

}