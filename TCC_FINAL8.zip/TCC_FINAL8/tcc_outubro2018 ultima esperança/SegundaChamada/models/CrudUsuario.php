<?php
/**
 * Created by PhpStorm.
 * User: Jéssica Yohana Otto
 * Date: 18/04/2018
 * Time: 13:24
 */

require_once 'Conexao.php';
require_once 'Usuario.php';


class CrudUsuario
{
    private $conexao;
    public $usuario;

    public function __construct()
    {
        $this->conexao = Conexao::getConexao();
    }

    public function cadastrar(Usuario $usuario)
    {
        $sql = ("INSERT INTO usuario (nome, email,tipo, senha, matricula) 

        VALUES ('{$usuario->getNome()}', '{$usuario->getEmail()}', '{$usuario->getTipo()}', '{$usuario->getSenha()}','{$usuario->getMatricula()}')");
        $this->conexao->exec($sql);
    }

    public function editar(Usuario $usuario)
    {
        $sql = "UPDATE usuario set nome = '{$usuario->getNome()}', email = '{$usuario->getEmail()}',
        senha = '{$usuario->getSenha()}' WHERE email = '{$usuario->getEmail()}'";

        $this->conexao->exec($sql);
    }

    public function excluir(Usuario $usuario)
    {
        $sql = "DELETE  FROM usuario WHERE email ='{$usuario->email}'";
        $this->conexao->exec($sql);
    }


    public function getAluno()
    {
        $consulta = $this->conexao->query("SELECT * FROM tipo_aluno");
        return $consulta->fetchAll(PDO::FETCH_ASSOC);
    }

    public function login(Usuario $usuario)
    {
        $sql = $this->conexao->prepare("SELECT email, nome, senha FROM usuario WHERE nome = '{$usuario->getNome()}' AND senha = '{$usuario->getSenha()}'");
        $sql->execute();
        $count = $sql->rowCount();
        try {
            if ($count == 1) {
                session_start();
                $_SESSION['logado'] = 'sim';
                $usuario = new CrudUsuario();
                $usuario->login();
                header('location: ../views/profile.php');
            }
        } catch
        (PDOException $e) {
            return $e->getMessage();
        }

    }
}
 /*switch ($obj->verificaTipo($user)) {
                    case 'aluno':
                        header('location: ../../index.php');
                        break;
                    case 'coordenaador':
                        $_SESSION['tipo'] = 'admin';
                        header('location: ../../index.php');
                        break;
                }else {
    header('location: ../../index.php?acao=login&erro=1');
}*/

