<?php
/**
 * Created by PhpStorm.
 * User: Guilherme Otto
 * Date: 24/11/2018
 * Time: 19:35
 */

class CrudParecer
{
    private $conexao;
    public $parecer ;

    public function __construct()
    {
        $this->conexao = Conexao::getConexao();
    }
    public function salvar(Parecer $parecer)
    {
        $sql = ("INSERT INTO Parecer (descricao) 
        VALUES ('{$parecer->getParecer()}')");

        $this->conexao->exec($sql);
    }



    }