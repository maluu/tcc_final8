<?php

//print_r($_POST);

//print_r($_GET);

//if (isset($_POST['name']) AND !empty($_POST['name'])) {
//	print_r($_POST);

//	echo $_POST['name'];
//	echo $_REQUEST['name'];

//} else {
//	echo "ainda nao tem nada";
//}
//_______________________________________________________


    $parecer  = $_POST['parecer'];

    $servidor="localhost";
    $usuario="root";
    $senha="";
    $dbname="segundachamada";
    //  if (!is_integer($nmatricula)) {
    //    header('location: ../views/cadastro.php?erro=verifique a matricula');
    //     exit();
    // }

   $conn=mysqli_connect($servidor, $usuario, $senha, $dbname);

   $result_parecer= "INSERT INTO parecer(parecer) VALUES ('$parecer')";

   $resusltado_parecer=mysqli_query($conn, $result_parecer);



header('location:../views/admindeshboard.php');
