<?php

session_start();

include '../models/Usuario.php';

$con = mysqli_connect("localhost","root","","segundachamada");
// Check connection
if (mysqli_connect_errno())
{
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$sql="SELECT * FROM usuario,pedido,parecer";
$id =

$result=mysqli_query($con,$sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<table border="1">
    <tr>
        <td>Nome</td>
        <td>Curso</td>
        <td>Turma</td>
        <td>Parecer</td>
        <td></td>

    </tr>
    <?php while ($dado = $result-> fetch_array()){?>
        <tr>

                <td><?php echo $dado['nome'];?></td>
                <td><?php echo $dado['curso'];?></td>
                <td><?php echo $dado['turma'];?></td>
                <td><?php echo $dado['parecer'];?></td>




        </tr>
    <?php }?>


</table>
</body>
</html>