<?php

session_start();

include '../models/Usuario.php';

$con = mysqli_connect("localhost","root","","segundachamada");
// Check connection
if (mysqli_connect_errno())
{
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$sql="SELECT * FROM pedido,usuario WHERE curso = 'informatica'";
$id =

$result=mysqli_query($con,$sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<style type="text/css">
  table#alter tr.duf td { /* Toda a tabela com fundo creme */
    background: #3c8dbc;
     color: white;
    } 
table#alter tr.dif td {
    background: #E6E6FA; /* Linhas com fundo cinza */ 
   
    }
</style>
<body>
<table border="1" cellpadding="5px" cellspacing="0" ID="alter">
    <tr class="duf">
        <td>ID</td>
        <td>Curso</td>
        <td>Turma</td>
        <td>Disciplina</td>
        <td>Professor</td>
        <td>Data</td>
        <td>Motivo</td>
        <td>Anexo</td>
        <td>Parecer</td>
        <td></td>

    </tr>
    <?php while ($dado = $result-> fetch_array()){?>
        <tr class="dif">

            <td><?php echo $dado['nome'];?></td>
            <td><?php echo $dado['curso'];?></td>
            <td><?php echo $dado['turma'];?></td>
            <td><?php echo $dado['disciplina'];?></td>
            <td><?php echo $dado['professor'];?></td>
            <td><?php echo $dado['dt_inicial'];?></td>
            <td><?php echo $dado['motivo'];?></td>
            <td><?php echo $dado['anexo'];?></td>

                 <form action="../controllers/parecer.php" method="post">
                <td><input type="RADIO" name="parecer" value="deferido">Deferido</td>
                <td><input type="RADIO" name="parecer" value="indeferido">Indeferido</td>

                <td><input type="submit" value="Parecer"> </td>

                </form>

        </tr>
    <?php }?>


</table>
</body>
</html>