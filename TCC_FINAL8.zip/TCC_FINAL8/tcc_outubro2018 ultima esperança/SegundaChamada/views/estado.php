<?php

session_start();

include '../models/Usuario.php';

$estado=$_POST['estado'];

if($estado = 'deferido'){
    echo ("<script>
    window.alert('deferido')
    window.location.href='profile.php';
   </script>");
} else {
    echo ("<script>
   window.alert('indeferido')
  window.location.href='informatica.php';
</script>");
}


$con = mysqli_connect("localhost","root","","segundachamada");
// Check connection
if (mysqli_connect_errno())
{
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$sql="INSERT into parecer (id_parecer,descrição,nome) values ('','$estado,$nome')";
$id =

$result=mysqli_query($con,$sql);



?>