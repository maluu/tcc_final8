-- Gera��o de Modelo f�sico
-- Sql ANSI 2003 - brModelo.



CREATE TABLE disciplina_turma (
cod_disciplina int(12),
cod_turma int(12),
cod_coordenador int(12),

FOREIGN KEY(cod_disciplina) REFERENCES disciplina (cod_disciplina),
FOREIGN KEY(cod_turma) REFERENCES turma (cod_turma),
FOREIGN KEY(cod_coordenador) REFERENCES coordenador (cod_coordenador)

);

CREATE TABLE disciplina (
nome text(80),
cod_disciplina int(12) PRIMARY KEY
);

CREATE TABLE disciplina_pedido (
cod_disciplina int(12),
cod_pedido int(12),

FOREIGN KEY(cod_disciplina) REFERENCES disciplina (cod_disciplina),
FOREIGN KEY(cod_pedido) REFERENCES pedido (cod_pedido)

);

CREATE TABLE coordenador (
cod_coordenador int(12) PRIMARY KEY,
nome text (80)
);

CREATE TABLE aluno (
matricula_aluno int(12) PRIMARY KEY,
email varchar(80),
senha varchar(80),
nome text(80),
turma varchar(80),
cod_turma int(12),

);

CREATE TABLE curso (
cod_curso int(12) PRIMARY KEY,
nome text(80),
cod_coordenador int(12),

FOREIGN KEY(cod_coordenador) REFERENCES coordenador (cod_coordenador)

);

CREATE TABLE turma (
cod_turma int(12) PRIMARY KEY,
nome text(80),
curso varchar(80),
ano int(12),
cod_curso int(12),

FOREIGN KEY(cod_curso) REFERENCES curso (cod_curso)
);

CREATE TABLE pedido (
data_parecer varchar(80),
cod_pedido int(12) PRIMARY KEY,
data_inicial varchar(80),
data_final varchar(80),
observa��o varchar(80),
motivo varchar(80),
cod_coordenador int(12),
status varchar(80),
anexo varchar(80),
data_pedido varchar(80),
matricula_aluno int(12),

FOREIGN KEY(cod_coordenador) REFERENCES coordenador (cod_coordenador),
FOREIGN KEY(matricula_aluno) REFERENCES aluno (matricula_aluno)
);

CREATE TABLE segundachamada (
cod_pedido int(12),
cod_disciplina int(12),
cod_coordenador int(12),

FOREIGN KEY(cod_disciplina) REFERENCES disciplina (cod_disciplina),
FOREIGN KEY(cod_pedido) REFERENCES pedido (cod_pedido),
FOREIGN KEY(cod_coordenador) REFERENCES coordenador (cod_coordenador)
);

ALTER TABLE aluno FOREIGN KEY(cod_turma) REFERENCES turma (cod_turma);

ALTER TABLE curso FOREIGN KEY(cod_coordendor) REFERENCES coordenador (cod_coordenador);

ALTER TABLE disciplina_pedido FOREIGN KEY(cod_disciplina) REFERENCES disciplina (cod_disciplina);

ALTER TABLE disciplina_pedido FOREIGN KEY(cod_pedido) REFERENCES pedido (cod_pedido);

ALTER TABLE disciplina_turma FOREIGN KEY(cod_disciplina) REFERENCES disciplina (cod_disciplina);

ALTER TABLE disciplina_turma FOREIGN KEY(cod_turma) REFERENCES turma (cod_turma);

ALTER TABLE disciplina_turma FOREIGN KEY(cod_coordendor) REFERENCES coordenador (cod_coordenador);

ALTER TABLE turma FOREIGN KEY(cod_curso) REFERENCES curso (cod_curso);

ALTER TABLE pedido FOREIGN KEY(cod_coordenador) REFERENCES coordenador (cod_coordenador);

ALTER TABLE pedido FOREIGN KEY(matricula_aluno) REFERENCES aluno (matricula_aluno);

ALTER TABLE segundachamada FOREIGN KEY(cod_pedido) REFERENCES pedido (cod_pedido);

ALTER TABLE segundachamada FOREIGN KEY(cod_disciplina) REFERENCES disciplina (cod_disciplina);

ALTER TABLE segundachamada FOREIGN KEY(cod_coordendor) REFERENCES coordenador (cod_coordenador);

