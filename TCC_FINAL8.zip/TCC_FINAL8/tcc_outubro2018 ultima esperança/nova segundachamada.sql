-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Tempo de geração: 22/10/2018 às 17:55
-- Versão do servidor: 5.7.21-0ubuntu0.16.04.1
-- Versão do PHP: 7.0.22-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `segundachamada`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `aluno`
--

CREATE TABLE `aluno` (
  `num_matricula` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=armscii8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `coordenador`
--

CREATE TABLE `coordenador` (
  `num_servidor` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=armscii8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `curso`
--

CREATE TABLE `curso` (
  `num_servidor` int(30) DEFAULT NULL,
  `nome` varchar(80) DEFAULT NULL,
  `cod_curso` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=armscii8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `disciplina`
--

CREATE TABLE `disciplina` (
  `nome` varchar(80) DEFAULT NULL,
  `cod_disciplina` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=armscii8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `disc_pedido`
--

CREATE TABLE `disc_pedido` (
  `cod_pedido` varchar(80) DEFAULT NULL,
  `cod_disciplina` int(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=armscii8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `dosc_turma`
--

CREATE TABLE `dosc_turma` (
  `cod_disciplina` int(30) DEFAULT NULL,
  `cod_turma` int(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=armscii8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `Pedido`
--

CREATE TABLE `Pedido` (
  `anexo` varchar(80) DEFAULT NULL,
  `num_matricula` int(30) DEFAULT NULL,
  `motivo` varchar(80) DEFAULT NULL,
  `dt_pedido` date DEFAULT NULL,
  `dt_inicial` date DEFAULT NULL,
  `cod_pedido` varchar(80) NOT NULL,
  `curso` varchar(80) DEFAULT NULL,
  `disciplina` varchar(80) DEFAULT NULL,
  `turma` varchar(80) DEFAULT NULL,
  `professor` varchar(80) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=armscii8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `Relação_1`
--

CREATE TABLE `Relação_1` (
  `num_matricula` int(30) DEFAULT NULL,
  `email` varchar(80) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=armscii8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `Relação_2`
--

CREATE TABLE `Relação_2` (
  `cod_turma` int(30) DEFAULT NULL,
  `num_matricula` int(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=armscii8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `Relação_3`
--

CREATE TABLE `Relação_3` (
  `num_servidor` int(30) DEFAULT NULL,
  `email` varchar(80) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=armscii8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `Relação_4`
--

CREATE TABLE `Relação_4` (
  `cod_turma` int(30) DEFAULT NULL,
  `cod_curso` int(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=armscii8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `Relação_5`
--

CREATE TABLE `Relação_5` (
  `num_matricula` int(30) DEFAULT NULL,
  `cod_pedido` varchar(80) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=armscii8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `Relação_6`
--

CREATE TABLE `Relação_6` (
  `num_servidor` int(30) DEFAULT NULL,
  `cod_disciplina` int(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=armscii8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tipo_user`
--

CREATE TABLE `tipo_user` (
  `nome` varchar(80) DEFAULT NULL,
  `email` varchar(80) NOT NULL,
  `senha` varchar(80) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=armscii8;

--
-- Fazendo dump de dados para tabela `tipo_user`
--

INSERT INTO `tipo_user` (`nome`, `email`, `senha`) VALUES
('Bruno ', 'bruno@gmail.com', 'topzera123'),
('Bruno ', 'brunophoda@gmail.com', '1234'),
('dfgdfgdfg', 'gfgfgfg@gmail.com', 'sfg'),
('Jessica Yohana Otto', 'jessicayohanaotto@gmail.com', 'jessica123'),
('maria luiza', 'marialuiza@gmail.com', '123456');

-- --------------------------------------------------------

--
-- Estrutura para tabela `turma`
--

CREATE TABLE `turma` (
  `cod_turma` int(30) NOT NULL,
  `cod_curso` int(30) DEFAULT NULL,
  `nome` varchar(80) DEFAULT NULL,
  `ano` varchar(80) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=armscii8;

--
-- Índices de tabelas apagadas
--

--
-- Índices de tabela `aluno`
--
ALTER TABLE `aluno`
  ADD PRIMARY KEY (`num_matricula`);

--
-- Índices de tabela `coordenador`
--
ALTER TABLE `coordenador`
  ADD PRIMARY KEY (`num_servidor`);

--
-- Índices de tabela `curso`
--
ALTER TABLE `curso`
  ADD PRIMARY KEY (`cod_curso`);

--
-- Índices de tabela `disciplina`
--
ALTER TABLE `disciplina`
  ADD PRIMARY KEY (`cod_disciplina`);

--
-- Índices de tabela `disc_pedido`
--
ALTER TABLE `disc_pedido`
  ADD KEY `cod_pedido` (`cod_pedido`),
  ADD KEY `cod_disciplina` (`cod_disciplina`);

--
-- Índices de tabela `dosc_turma`
--
ALTER TABLE `dosc_turma`
  ADD KEY `cod_disciplina` (`cod_disciplina`);

--
-- Índices de tabela `Pedido`
--
ALTER TABLE `Pedido`
  ADD PRIMARY KEY (`cod_pedido`);

--
-- Índices de tabela `Relação_1`
--
ALTER TABLE `Relação_1`
  ADD KEY `num_matricula` (`num_matricula`),
  ADD KEY `email` (`email`);

--
-- Índices de tabela `Relação_2`
--
ALTER TABLE `Relação_2`
  ADD KEY `cod_turma` (`cod_turma`),
  ADD KEY `num_matricula` (`num_matricula`);

--
-- Índices de tabela `Relação_3`
--
ALTER TABLE `Relação_3`
  ADD KEY `num_servidor` (`num_servidor`),
  ADD KEY `email` (`email`);

--
-- Índices de tabela `Relação_4`
--
ALTER TABLE `Relação_4`
  ADD KEY `cod_turma` (`cod_turma`),
  ADD KEY `cod_curso` (`cod_curso`);

--
-- Índices de tabela `Relação_5`
--
ALTER TABLE `Relação_5`
  ADD KEY `num_matricula` (`num_matricula`),
  ADD KEY `cod_pedido` (`cod_pedido`);

--
-- Índices de tabela `Relação_6`
--
ALTER TABLE `Relação_6`
  ADD KEY `num_servidor` (`num_servidor`),
  ADD KEY `cod_disciplina` (`cod_disciplina`);

--
-- Índices de tabela `tipo_user`
--
ALTER TABLE `tipo_user`
  ADD PRIMARY KEY (`email`);

--
-- Índices de tabela `turma`
--
ALTER TABLE `turma`
  ADD PRIMARY KEY (`cod_turma`);

--
-- Restrições para dumps de tabelas
--

--
-- Restrições para tabelas `disc_pedido`
--
ALTER TABLE `disc_pedido`
  ADD CONSTRAINT `disc_pedido_ibfk_1` FOREIGN KEY (`cod_pedido`) REFERENCES `Pedido` (`cod_pedido`),
  ADD CONSTRAINT `disc_pedido_ibfk_2` FOREIGN KEY (`cod_disciplina`) REFERENCES `disciplina` (`cod_disciplina`);

--
-- Restrições para tabelas `dosc_turma`
--
ALTER TABLE `dosc_turma`
  ADD CONSTRAINT `dosc_turma_ibfk_1` FOREIGN KEY (`cod_disciplina`) REFERENCES `disciplina` (`cod_disciplina`);

--
-- Restrições para tabelas `Relação_1`
--
ALTER TABLE `Relação_1`
  ADD CONSTRAINT `Relação_1_ibfk_1` FOREIGN KEY (`num_matricula`) REFERENCES `aluno` (`num_matricula`),
  ADD CONSTRAINT `Relação_1_ibfk_2` FOREIGN KEY (`email`) REFERENCES `tipo_user` (`email`);

--
-- Restrições para tabelas `Relação_2`
--
ALTER TABLE `Relação_2`
  ADD CONSTRAINT `Relação_2_ibfk_1` FOREIGN KEY (`cod_turma`) REFERENCES `turma` (`cod_turma`),
  ADD CONSTRAINT `Relação_2_ibfk_2` FOREIGN KEY (`num_matricula`) REFERENCES `aluno` (`num_matricula`);

--
-- Restrições para tabelas `Relação_3`
--
ALTER TABLE `Relação_3`
  ADD CONSTRAINT `Relação_3_ibfk_1` FOREIGN KEY (`num_servidor`) REFERENCES `coordenador` (`num_servidor`),
  ADD CONSTRAINT `Relação_3_ibfk_2` FOREIGN KEY (`email`) REFERENCES `tipo_user` (`email`);

--
-- Restrições para tabelas `Relação_4`
--
ALTER TABLE `Relação_4`
  ADD CONSTRAINT `Relação_4_ibfk_1` FOREIGN KEY (`cod_turma`) REFERENCES `turma` (`cod_turma`),
  ADD CONSTRAINT `Relação_4_ibfk_2` FOREIGN KEY (`cod_curso`) REFERENCES `curso` (`cod_curso`);

--
-- Restrições para tabelas `Relação_5`
--
ALTER TABLE `Relação_5`
  ADD CONSTRAINT `Relação_5_ibfk_1` FOREIGN KEY (`num_matricula`) REFERENCES `aluno` (`num_matricula`),
  ADD CONSTRAINT `Relação_5_ibfk_2` FOREIGN KEY (`cod_pedido`) REFERENCES `Pedido` (`cod_pedido`);

--
-- Restrições para tabelas `Relação_6`
--
ALTER TABLE `Relação_6`
  ADD CONSTRAINT `Relação_6_ibfk_1` FOREIGN KEY (`num_servidor`) REFERENCES `coordenador` (`num_servidor`),
  ADD CONSTRAINT `Relação_6_ibfk_2` FOREIGN KEY (`cod_disciplina`) REFERENCES `disciplina` (`cod_disciplina`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
