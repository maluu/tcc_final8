-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 25-Nov-2018 às 12:48
-- Versão do servidor: 10.1.30-MariaDB
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `segundachamada`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `parecer`
--

CREATE TABLE `parecer` (
  `id_parecer` int(1) NOT NULL,
  `parecer` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=armscii8;

--
-- Extraindo dados da tabela `parecer`
--

INSERT INTO `parecer` (`id_parecer`, `parecer`) VALUES
(2, 'deferido'),
(3, 'deferido'),
(4, 'indeferido'),
(5, 'deferido'),
(6, 'deferido'),
(7, 'deferido'),
(8, 'indeferido');

-- --------------------------------------------------------

--
-- Estrutura da tabela `pedido`
--

CREATE TABLE `pedido` (
  `motivo` varchar(80) DEFAULT NULL,
  `dt_inicial` date DEFAULT NULL,
  `cod_pedido` int(11) NOT NULL,
  `curso` varchar(80) DEFAULT NULL,
  `disciplina` varchar(80) DEFAULT NULL,
  `turma` varchar(80) DEFAULT NULL,
  `professor` varchar(80) DEFAULT NULL,
  `anexo` varchar(1000) DEFAULT NULL,
  `fk_matricula` int(32) DEFAULT NULL,
  `estado` varchar(80) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=armscii8;

--
-- Extraindo dados da tabela `pedido`
--

INSERT INTO `pedido` (`motivo`, `dt_inicial`, `cod_pedido`, `curso`, `disciplina`, `turma`, `professor`, `anexo`, `fk_matricula`, `estado`) VALUES
('das', '2018-10-03', 1, 'asda', 'asd', 'asdas', 'asd', '30102018100227Captura de tela de 2018-09-03 10-26-52.png', 0, NULL),
('ah tava votando no bolsomistoquente', '2018-10-02', 2, 'informatica', 'projeto', '3info1', 'kelly', '30102018100401Captura de tela de 2018-09-03 09-53-36.png', 0, NULL),
(NULL, NULL, 5, NULL, NULL, NULL, NULL, NULL, 0, '1'),
(NULL, NULL, 6, NULL, NULL, NULL, NULL, NULL, 0, '2'),
('Bla', '2018-10-26', 7, 'info', 'bla', '3info1', 'Ivo', NULL, NULL, NULL),
('bla', '2222-12-12', 8, 'informatica', 'banco', '3info1', 'ivo', '', NULL, NULL),
('gfrde', '2011-04-13', 9, 'informatica', 'edfisica', '3info1', 'jonathan', NULL, NULL, NULL),
('treaar', '3214-03-12', 10, 'agro', 'menejo', '2agoa2', 'frederico', 'https://www.google.com.br/url?sa=i&source=images&cd=&cad=rja&uact=8&ved=2ahUKEwiinN3o_OzeAhVGIZAKHU_RDWEQjRx6BAgBEAU&url=https%3A%2F%2Fwww.imgworlds.com%2Flanguage%2Fen%2Fcontact-us%2F&psig=AOvVaw27tLkJqSExt1o493jkpW6W&ust=1543147028859223', NULL, NULL),
('oi', '1223-12-12', 11, 'agropecuaria', 'manejo', '3agro1', 'carla', 'https://www.google.com.br/url?sa=i&source=images&cd=&cad=rja&uact=8&ved=2ahUKEwiinN3o_OzeAhVGIZAKHU_RDWEQjRx6BAgBEAU&url=https%3A%2F%2Fwww.imgworlds.com%2Flanguage%2Fen%2Fcontact-us%2F&psig=AOvVaw27tLkJqSExt1o493jkpW6W&ust=1543147028859223', NULL, NULL),
('gfrde', '1212-12-12', 12, 'quimica', 'edfisica', '4quimi', 'ivo', 'https://www.google.com.br/url?sa=i&source=images&cd=&cad=rja&uact=8&ved=2ahUKEwiinN3o_OzeAhVGIZAKHU_RDWEQjRx6BAgBEAU&url=https%3A%2F%2Fwww.imgworlds.com%2Flanguage%2Fen%2Fcontact-us%2F&psig=AOvVaw27tLkJqSExt1o493jkpW6W&ust=1543147028859223', NULL, NULL),
('gfdnghifwo', '3323-02-23', 13, 'agro', 'dewfrew', '21agro2', 'rewrewr', 'https://www.google.com.br/url?sa=i&source=images&cd=&cad=rja&uact=8&ved=2ahUKEwiinN3o_OzeAhVGIZAKHU_RDWEQjRx6BAgBEAU&url=https%3A%2F%2Fwww.imgworlds.com%2Flanguage%2Fen%2Fcontact-us%2F&psig=AOvVaw27tLkJqSExt1o493jkpW6W&ust=1543147028859223', NULL, NULL),
('gtrhrteherh', '0000-00-00', 14, 'agropecuaria', 'dqDWfewds', '25agro3', 'vadvbfdbfd', 'https://www.google.com.br/url?sa=i&source=images&cd=&cad=rja&uact=8&ved=2ahUKEwiinN3o_OzeAhVGIZAKHU_RDWEQjRx6BAgBEAU&url=https%3A%2F%2Fwww.imgworlds.com%2Flanguage%2Fen%2Fcontact-us%2F&psig=AOvVaw27tLkJqSExt1o493jkpW6W&ust=1543147028859223', NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipo_usuario`
--

CREATE TABLE `tipo_usuario` (
  `id_tipo` int(10) NOT NULL,
  `descricao` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=armscii8;

--
-- Extraindo dados da tabela `tipo_usuario`
--

INSERT INTO `tipo_usuario` (`id_tipo`, `descricao`) VALUES
(1, 'Aluno'),
(2, 'Coordenador');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `nome` varchar(80) DEFAULT NULL,
  `senha` varchar(80) DEFAULT NULL,
  `foto` varchar(1000) DEFAULT NULL,
  `email` varchar(80) NOT NULL,
  `matricula` int(32) NOT NULL,
  `tipo` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=armscii8;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`nome`, `senha`, `foto`, `email`, `matricula`, `tipo`) VALUES
('jessica', '4535', NULL, 'dsiufu@fiohg.gor', 43534, 'aluno'),
('rafael la', 'cmFmYWVs', NULL, 'rafal@gmail.com', 212121, 'aluno'),
('jessica', '12344321', NULL, 'oitudobem@olabuenas.com', 1234431, 'coordenador'),
('guilherme otto', '56456546546', NULL, 'guilherme_otto@outlook.com', 6456546, 'coordenador'),
('rafael', '1123432', NULL, 'rafa@gmail.com', 6456547, 'aluno'),
('yohana', '12434', NULL, 'yohana@gmail.com', 35454656, 'coordenador'),
('jessica', 'malu', NULL, 'jessicayohanaotto@gmail.com', 2016301520, ''),
('Guilherme Cipriano', 'cipriano', NULL, 'guuilherme.cp@live.com', 2016301626, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `parecer`
--
ALTER TABLE `parecer`
  ADD PRIMARY KEY (`id_parecer`);

--
-- Indexes for table `pedido`
--
ALTER TABLE `pedido`
  ADD PRIMARY KEY (`cod_pedido`),
  ADD KEY `fk_matricula` (`fk_matricula`);

--
-- Indexes for table `tipo_usuario`
--
ALTER TABLE `tipo_usuario`
  ADD PRIMARY KEY (`id_tipo`);

--
-- Indexes for table `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`matricula`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `parecer`
--
ALTER TABLE `parecer`
  MODIFY `id_parecer` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `pedido`
--
ALTER TABLE `pedido`
  MODIFY `cod_pedido` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tipo_usuario`
--
ALTER TABLE `tipo_usuario`
  MODIFY `id_tipo` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `usuario`
--
ALTER TABLE `usuario`
  MODIFY `matricula` int(32) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2016301628;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
